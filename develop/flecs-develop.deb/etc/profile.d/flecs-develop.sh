#!/bin/sh

export FLECS_DEVELOPMENT=1
